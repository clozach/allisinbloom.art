/** SPDX-License-Identifier: AGPL-3.0-only */
export interface EditEntry {
    editId: string;
}
export interface HistorySnapshot<T extends EditEntry> {
    readonly undoStack: readonly T[];
    readonly redoStack: readonly T[];
    readonly pending: boolean;
    readonly canUndo: boolean;
    readonly canRedo: boolean;
}
export interface EditHistory<T extends EditEntry> {
    getSnapshot(): HistorySnapshot<T>;
    subscribe(listener: (snapshot: HistorySnapshot<T>) => void): () => void;
    record(edit: T): void;
    reverseEntry(edit: T, lane?: "undo" | "redo"): Promise<T | null>;
    undoEntry(edit: T): Promise<T | null>;
    undo(): Promise<T | null>;
    redo(): Promise<T | null>;
    forget(idOrPredicate: string | ((edit: T) => boolean)): void;
}
export function createEditHistory<T extends EditEntry>(
    reverse: (edit: T) => Promise<T | null>,
): EditHistory<T>;
export type ReversedChange<T extends { before: unknown; after: unknown }> =
    T extends unknown
        ? Omit<T, "before" | "after"> & {
              before: T["after"];
              after: T["before"];
          }
        : never;
export function reverseChanges<T extends { before: unknown; after: unknown }>(
    changes: readonly T[],
): ReversedChange<T>[];
export { reverseChanges as reversed };
export interface Snapshot {
    parents: Array<[Element, ChildNode[]]>;
    texts: Array<[Text, string]>;
}
export function snapshotTree(root: Element): Snapshot;
export function restoreTree(snapshot: Snapshot): void;
export function placeCaretAtEnd(element: Element): void;
