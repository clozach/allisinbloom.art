/* SPDX-License-Identifier: AGPL-3.0-only */
import core from "./index.cjs";
export const {
    createEditHistory,
    reverseChanges,
    reversed,
    snapshotTree,
    restoreTree,
    placeCaretAtEnd,
} = core;
