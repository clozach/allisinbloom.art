# Source and license

The journal and DOM recovery routines originate in the SwamiKK CourseLit fork at
`clozach/swamikk`, baseline `c0dd8f774069d76e2bef2cfdec33f1da1e850b7a`:

- `apps/web/components/section-edit/use-edit-history.ts`
- `apps/web/components/feedback/text-edit/use-text-edit.ts`

Original contribution history credits Chris Lozac'h and Elbong Gearny. This
extraction removes React from the generic journal and adds CommonJS/ESM exports,
TypeScript declarations and reusable tests. No text normalization or poem content
is included.

The repository's package metadata says MIT, but its actual root `LICENSE.md`
contains GNU Affero General Public License version 3. This package retains that
AGPL-3.0 license text and declares `AGPL-3.0-only`; it does not relicense the
extracted source based on conflicting package metadata. Preserve this notice and
`LICENSE.md` in every packed consumer copy.
