# Shared inline-edit core

One dependency-free implementation serves SwamiKK's React editor and
allisinbloom.art's Svelte editor. The package includes its source in the archive.
It does not read storage, issue requests, authenticate, or normalize text.

`createEditHistory(reverse)` owns saved-edit undo/redo stacks. The host's async
`reverse(edit)` persists a reversal and returns its new retained history row;
return `null` when refused or throw on a transport error. Both retain the entry
for retry. Repeated undo while a reversal is pending returns `null`. Recording a
new edit clears redo. `reverseEntry(edit, lane?)` retains SwamiKK's targeted
history behavior; `undoEntry(edit)` explicitly restores that entry's before
value. `forget(id)` removes one entry; a predicate supports host-specific cleanup.

`subscribe(listener)` immediately provides the current immutable snapshot and
returns unsubscribe. `getSnapshot()` returns the same object until state changes.
Snapshots include `undoStack`, `redoStack`, `pending`, `canUndo`, `canRedo`.
Do not mutate entries supplied to the journal. UI hosts block conflicting edits
while `pending`; the package serializes reversal operations.

`reverseChanges(changes)` swaps opaque before/after values. `snapshotTree` and
`restoreTree` preserve actual DOM node identity and exact whitespace when a
framework-owned field enters/leaves contentEditable. `placeCaretAtEnd` uses the
field's document. These helpers deliberately do not choose keys, serialization,
formatting, save timing, or durable storage.

Run `pnpm --filter @courselit/inline-edit test` and `build`. Pack with
`pnpm --filter @courselit/inline-edit pack --pack-destination /tmp`. Consumer
archives are versioned artifacts; update both consumers from this canonical
workspace and record the archive checksum. Read NOTICE.md for source provenance.
