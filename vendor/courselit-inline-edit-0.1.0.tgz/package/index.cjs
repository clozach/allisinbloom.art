/* SPDX-License-Identifier: AGPL-3.0-only
 * Extracted from the SwamiKK CourseLit fork; see NOTICE.md. */
"use strict";

/** Ordered saved-edit journal. Persistence and authorization belong to the host. */
function createEditHistory(reverse) {
    let undoStack = [];
    let redoStack = [];
    let pending = false;
    const listeners = new Set();
    const makeSnapshot = () =>
        Object.freeze({
            undoStack: Object.freeze([...undoStack]),
            redoStack: Object.freeze([...redoStack]),
            pending,
            canUndo: !pending && undoStack.length > 0,
            canRedo: !pending && redoStack.length > 0,
        });
    let snapshot = makeSnapshot();
    // A broken view must not turn a saved reversal into a failed operation or lock history.
    const notify = (listener) => {
        try {
            listener(snapshot);
        } catch (error) {
            if (typeof globalThis.reportError === "function")
                globalThis.reportError(error);
            else
                queueMicrotask(() => {
                    throw error;
                });
        }
    };
    const publish = () => {
        snapshot = makeSnapshot();
        for (const listener of listeners) notify(listener);
    };
    const record = (edit) => {
        undoStack = [...undoStack, edit];
        redoStack = [];
        publish();
    };
    const reverseEntry = async (edit, lane) => {
        if (pending) return null;
        pending = true;
        try {
            publish();
            const from =
                lane ??
                (undoStack.some((item) => item.editId === edit.editId)
                    ? "undo"
                    : "redo");
            const result = await reverse(edit);
            if (!result) return null;
            undoStack = undoStack.filter((item) => item.editId !== edit.editId);
            redoStack = redoStack.filter((item) => item.editId !== edit.editId);
            if (from === "undo") redoStack.push(result);
            else undoStack.push(result);
            return result;
        } finally {
            pending = false;
            publish();
        }
    };
    const forget = (idOrPredicate) => {
        const matches =
            typeof idOrPredicate === "function"
                ? idOrPredicate
                : (edit) => edit.editId === idOrPredicate;
        undoStack = undoStack.filter((edit) => !matches(edit));
        redoStack = redoStack.filter((edit) => !matches(edit));
        publish();
    };
    return {
        getSnapshot: () => snapshot,
        subscribe(listener) {
            listeners.add(listener);
            notify(listener);
            return () => {
                listeners.delete(listener);
            };
        },
        record,
        reverseEntry,
        undoEntry: (edit) => reverseEntry(edit, "undo"),
        undo: () =>
            undoStack.length
                ? reverseEntry(undoStack[undoStack.length - 1], "undo")
                : Promise.resolve(null),
        redo: () =>
            redoStack.length
                ? reverseEntry(redoStack[redoStack.length - 1], "redo")
                : Promise.resolve(null),
        forget,
    };
}

/** Reverse every before/after pair without interpreting its content. */
function reverseChanges(changes) {
    return changes.map((change) => ({
        ...change,
        before: change.after,
        after: change.before,
    }));
}

/** Retain the framework's own node identities before contentEditable changes them. */
function snapshotTree(root) {
    const parents = [];
    const texts = [];
    const visit = (element) => {
        parents.push([element, Array.from(element.childNodes)]);
        element.childNodes.forEach((node) => {
            if (node.nodeType === 3) texts.push([node, node.nodeValue || ""]);
            else if (node.nodeType === 1) visit(node);
        });
    };
    visit(root);
    return { parents, texts };
}

function restoreTree(snapshot) {
    for (const [element, children] of snapshot.parents) {
        while (element.firstChild) element.removeChild(element.firstChild);
        for (const child of children) element.appendChild(child);
    }
    for (const [text, value] of snapshot.texts) text.nodeValue = value;
}

function placeCaretAtEnd(element) {
    const document = element.ownerDocument;
    const selection = document.defaultView?.getSelection();
    if (!selection) return;
    const range = document.createRange();
    range.selectNodeContents(element);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);
}

module.exports = {
    createEditHistory,
    reverseChanges,
    reversed: reverseChanges,
    snapshotTree,
    restoreTree,
    placeCaretAtEnd,
};
